/*
SQLyog Community v12.2.5 (32 bit)
MySQL - 10.4.32-MariaDB : Database - tokobuku
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`tokobuku` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `tokobuku`;

/*Table structure for table `buku` */

DROP TABLE IF EXISTS `buku`;

CREATE TABLE `buku` (
  `ID` int(11) NOT NULL,
  `Judul` varchar(255) DEFAULT NULL,
  `Pengarang` varchar(255) DEFAULT NULL,
  `Harga` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `buku` */

insert  into `buku`(`ID`,`Judul`,`Pengarang`,`Harga`) values 

(1,'Harry Potter and the Philosopher\'s Stone','J.K. Rowling','20.50'),

(2,'To Kill a Mockingbird','Harper Lee','15.75'),

(3,'The Great Gatsby','F. Scott Fitzgerald','12.99'),

(4,'1984','George Orwell','18.25'),

(5,'The Catcher in the Rye','J.D. Salinger','14.50'),

(6,'Lord of the Flies','William Golding','16.80'),

(7,'Pride and Prejudice','Jane Austen','10.99'),

(8,'The Hobbit','J.R.R. Tolkien','22.00'),

(9,'The Da Vinci Code','Dan Brown','19.95'),

(10,'To Kill a Mockingbird','Harper Lee','15.75'),

(11,'The Lord of the Rings','J.R.R. Tolkien','25.50'),

(12,'The Hunger Games','Suzanne Collins','13.25'),

(13,'The Alchemist','Paulo Coelho','11.99'),

(14,'The Chronicles of Narnia','C.S. Lewis','21.75'),

(15,'Gone with the Wind','Margaret Mitchell','20.99'),

(16,'The Kite Runner','Khaled Hosseini','17.50'),

(17,'The Girl with the Dragon Tattoo','Stieg Larsson','14.75'),

(18,'The Odyssey','Homer','12.80'),

(19,'Jane Eyre','Charlotte Brontë','16.99'),

(20,'The Picture of Dorian Gray','Oscar Wilde','11.50'),

(21,'The Hitchhiker\'s Guide to the Galaxy','Douglas Adams','18.25'),

(22,'Moby-Dick','Herman Melville','23.00'),

(23,'A Game of Thrones','George R.R. Martin','19.95'),

(24,'Brave New World','Aldous Huxley','14.99'),

(25,'The Shining','Stephen King','16.50'),

(26,'Frankenstein','Mary Shelley','12.75'),

(27,'War and Peace','Leo Tolstoy','27.50'),

(28,'Wuthering Heights','Emily Brontë','15.75'),

(29,'The Road','Cormac McCarthy','13.99'),

(30,'Don Quixote','Miguel de Cervantes','20.50'),

(31,'One Hundred Years of Solitude','Gabriel García Márquez','18.25'),

(32,'The Bell Jar','Sylvia Plath','14.80'),

(33,'Crime and Punishment','Fyodor Dostoevsky','16.95'),

(34,'The Brothers Karamazov','Fyodor Dostoevsky','22.99'),

(35,'The Count of Monte Cristo','Alexandre Dumas','19.50'),

(36,'Les Misérables','Victor Hugo','24.75'),

(37,'Slaughterhouse-Five','Kurt Vonnegut','13.99'),

(38,'The Sun Also Rises','Ernest Hemingway','15.25'),

(39,'Anna Karenina','Leo Tolstoy','21.99'),

(40,'Catch-22','Joseph Heller','17.50'),

(41,'A Tale of Two Cities','Charles Dickens','16.80'),

(42,'Great Expectations','Charles Dickens','18.99'),

(43,'The Road','Cormac McCarthy','13.99'),

(44,'Life of Pi','Yann Martel','14.75'),

(45,'The Handmaid\'s Tale','Margaret Atwood','15.80'),

(46,'The Giver','Lois Lowry','11.99'),

(47,'The Martian','Andy Weir','18.50'),

(48,'The Help','Kathryn Stockett','14.25'),

(49,'The Stand','Stephen King','21.99'),

(50,'The Color Purple','Alice Walker','12.50');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
